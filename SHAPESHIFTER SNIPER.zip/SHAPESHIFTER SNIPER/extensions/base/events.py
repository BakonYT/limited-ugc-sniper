def start():
    pass

def iteration():
    pass

def end():
    pass